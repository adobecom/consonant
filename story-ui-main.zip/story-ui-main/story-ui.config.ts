import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Component configuration interface
export interface ComponentConfig {
  name: string;
  displayName?: string;
  importPath?: string;
  props?: string[];
  examples?: string[];
  description?: string;
  category?: 'layout' | 'content' | 'form' | 'navigation' | 'feedback' | 'other';
  slots?: string[];
}

// Layout rules configuration
export interface LayoutRules {
  multiColumnWrapper: string;
  columnComponent: string;
  containerComponent?: string;
  layoutExamples?: {
    twoColumn?: string;
    threeColumn?: string;
    [key: string]: string | undefined;
  };
  prohibitedElements?: string[];
}

// Additional imports configuration
export interface AdditionalImport {
  path: string;
  components: string[];
}

// Icon imports configuration (auto-detected or manual)
export interface IconImportsConfig {
  /** Package name for icon imports (e.g., '@tabler/icons-react', 'lucide-react') */
  package: string;
  /** Import path pattern (e.g., '@tabler/icons-react' or 'lucide-react') */
  importPath: string;
  /** Common icons that are known to exist (for validation fallback) */
  commonIcons?: string[];
  /** Whether to allow any icon from this package (skip individual validation) */
  allowAllIcons?: boolean;
}



// Design system guidelines configuration
export interface DesignSystemGuidelines {
  name: string;
  preferredComponents?: {
    [category: string]: string; // category -> package path
  };
  spacingTokens?: {
    prefix: string;
    values: string[];
  };
  colorTokens?: {
    prefix: string;
    categories: string[];
  };
  prohibitedPatterns?: {
    cssFrameworks?: string[];
    classNamePatterns?: string[];
    inlineStyles?: string[];
  };
  enforcementRules?: {
    requireDesignTokens?: boolean;
    prohibitArbitraryValues?: boolean;
    enforceComponentLibrary?: boolean;
  };
  /** Additional notes/guidelines for AI story generation (e.g., shadcn-specific instructions) */
  additionalNotes?: string;
}

// Main Story UI configuration interface
export interface StoryUIConfig {
  generatedStoriesPath: string;
  componentsPath?: string;
  componentsMetadataPath?: string;
  storyPrefix: string;
  defaultAuthor: string;
  importPath: string;
  componentPrefix: string;
  /** Framework type for story generation (e.g., 'react', 'web-components', 'angular', 'vue', 'svelte') */
  framework?: string;
  /** Component framework type for discovery routing (e.g., 'react', 'vue', 'angular', 'svelte', 'web-components') */
  componentFramework?: string;
  components: ComponentConfig[];
  layoutComponents?: ComponentConfig[]; // Layout-specific components
  layoutRules: LayoutRules;
  sampleStory: string;
  systemPrompt?: string;
  layoutInstructions?: string[];
  examples?: string[];
  additionalImports?: AdditionalImport[];
  considerationsPath?: string;
  storybookFramework?: string; // e.g., '@storybook/react-vite', '@storybook/react-webpack5', '@storybook/nextjs'
  /**
   * Import style for generated stories:
   * - 'barrel': Use barrel imports from a single entry point (e.g., `import { Button } from 'library'`)
   * - 'individual': Use individual file imports (e.g., `import { Button } from 'library/button'`)
   *
   * Use 'individual' for libraries without barrel exports (index.ts), such as:
   * - shadcn/ui, Radix Vue, PrimeVue (Vue)
   * - Angular Material, PrimeNG (Angular)
   * - Shoelace, Lion (Web Components)
   *
   * Use 'barrel' (default) for libraries with barrel exports, such as:
   * - Chakra UI, Mantine, Ant Design (React)
   * - Vuetify, Quasar (Vue)
   * - Skeleton UI (Svelte)
   */
  importStyle?: 'barrel' | 'individual';
  designSystemGuidelines?: DesignSystemGuidelines;
  /** Icon imports configuration (auto-detected from package.json or manually configured) */
  iconImports?: IconImportsConfig;
  /**
   * Example import statements to guide the LLM on correct import patterns.
   * Useful for Web Components or custom folder structures.
   * Example: ["import '../../../components/alert/alert'; // For <al-alert> component"]
   */
  importExamples?: string[];
  /**
   * Storybook MCP server URL for enhanced context during story generation.
   * When configured, Story UI will fetch component documentation, design tokens,
   * and existing story patterns from Storybook MCP to improve generation quality.
   *
   * Example: 'http://localhost:6006' (local Storybook) or 'https://storybook.example.com'
   *
   * If the Storybook instance has @storybook/addon-mcp enabled, Story UI will
   * automatically use it to gather context about existing components and patterns.
   */
  storybookMcpUrl?: string;
  /**
   * Timeout in milliseconds for Storybook MCP requests.
   * Default: 5000 (5 seconds)
   */
  storybookMcpTimeout?: number;
}

// Default generic configuration
export const DEFAULT_CONFIG: StoryUIConfig = {
  generatedStoriesPath: path.resolve(process.cwd(), './src/stories/generated/'),
  componentsPath: undefined, // No default path - should be set only for local component libraries
  componentsMetadataPath: undefined,
  storyPrefix: 'Generated/',
  defaultAuthor: 'Story UI AI',
  importPath: 'your-component-library',
  componentPrefix: '',
  components: [], // Will be populated dynamically
  layoutRules: {
    multiColumnWrapper: 'div',
    columnComponent: 'div',
    containerComponent: 'div',
    layoutExamples: {
      twoColumn: `<div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem'}}>
  <div>
    <Card>
      <h3>Left Card</h3>
      <p>Left content</p>
    </Card>
  </div>
  <div>
    <Card>
      <h3>Right Card</h3>
      <p>Right content</p>
    </Card>
  </div>
</div>`,
      threeColumn: `<div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem'}}>
  <div>
    <Card>
      <h3>Column 1</h3>
      <p>First column content</p>
    </Card>
  </div>
  <div>
    <Card>
      <h3>Column 2</h3>
      <p>Second column content</p>
    </Card>
  </div>
  <div>
    <Card>
      <h3>Column 3</h3>
      <p>Third column content</p>
    </Card>
  </div>
</div>`
    },
    prohibitedElements: []
  },
  sampleStory: `import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Card } from 'your-component-library';

const meta = {
  title: 'Generated/Sample Layout',
  component: Card,
  parameters: {
    layout: 'centered',
  },
} satisfies Meta<typeof Card>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    children: (
      <Card>
        <h3>Sample Card</h3>
        <p>Sample content</p>
      </Card>
    )
  }
};`
};

// Generic configuration template for other design systems
export const GENERIC_CONFIG_TEMPLATE: Partial<StoryUIConfig> = {
  storyPrefix: 'Generated/',
  defaultAuthor: 'Story UI AI',
  componentPrefix: '',
  layoutRules: {
    multiColumnWrapper: 'div',
    columnComponent: 'div',
    layoutExamples: {
      twoColumn: `<div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem'}}>
  <div>Column 1 content</div>
  <div>Column 2 content</div>
</div>`,
      threeColumn: `<div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem'}}>
  <div>Column 1 content</div>
  <div>Column 2 content</div>
  <div>Column 3 content</div>
</div>`
    },
    prohibitedElements: []
  }
};

// Default configuration - should be overridden by user's story-ui.config.js
export const STORY_UI_CONFIG: StoryUIConfig = DEFAULT_CONFIG;

// Function to merge user config with defaults
export function createStoryUIConfig(userConfig: Partial<StoryUIConfig>): StoryUIConfig {
  return {
    ...DEFAULT_CONFIG,
    ...userConfig,
    layoutRules: {
      ...DEFAULT_CONFIG.layoutRules,
      ...userConfig.layoutRules,
      layoutExamples: {
        ...DEFAULT_CONFIG.layoutRules.layoutExamples,
        ...userConfig.layoutRules?.layoutExamples
      }
    }
  };
}
